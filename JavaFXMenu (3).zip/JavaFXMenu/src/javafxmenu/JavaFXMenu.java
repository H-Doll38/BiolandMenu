/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxmenu;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.File;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Scene;
import javafx.scene.Group;
import javafx.scene.text.Text;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.HBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.image.*;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.GridPane;


/**
 *
 * @author flodo
 */
public class JavaFXMenu extends Application {
    
    @Override
    public void start(Stage primaryStage) throws FileNotFoundException {
        Button entbtn = new Button();
        Button quitbtn = new Button();
        Group group =new Group();
        Text Title = new Text();
        
        //Buttons
         entbtn.setText("Start");
         entbtn.setStyle("-fx-font-size: 3em;");
         entbtn.setPrefSize(200, 100);
         quitbtn.setText("Quit");
         quitbtn.setStyle("-fx-font-size: 3em;");
         quitbtn.setPrefSize(200,100);
         entbtn.setDefaultButton(true);
         HBox hbox = new HBox(entbtn,quitbtn);
         HBox.setMargin(entbtn, new Insets(10, 10, 50, 100));
         HBox.setMargin(quitbtn, new Insets(10,10,50,20));
         hbox.setAlignment(Pos.BOTTOM_CENTER);
         
         //Quit Button
          quitbtn.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
              primaryStage.close();
            }
        });
          //Enter Button
            entbtn.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
              primaryStage.close();
            }
        });
         
         //Title
         Title.setText("Bioland");
         Title.setFont(Font.font("TimesNewRoman",200));
         Title.setTextOrigin(VPos.BOTTOM);
         
//         Image image = new Image("Main Menu.jpg", 400, 400, true, true);
//         ImageView ImageView = new ImageView(image);
//         GridPane gPane = new GridPane();
//         gPane.add(ImageView,0,0);
//         ImageView.setFitHeight(950);
//         ImageView.setFitWidth(700);
//         ImageView.setPreserveRatio(true);
         
         
//         BackgroundImage BackgroundImage= new BackgroundImage(image,BackgroundRepeat.NO_REPEAT,  
//                                             BackgroundRepeat.NO_REPEAT,  
//                                             BackgroundPosition.DEFAULT,  
//                                             BackgroundSize.DEFAULT);
         
         //Group
         group.getChildren().add(hbox);
         group.getChildren().add(Title);
//         group.getChildren().add(gPane);
         //group.getChildren().add(ImageView);
         group.setLayoutX(160);
         group.setLayoutY(350);
         
         
        
        
        Scene scene = new Scene(group, 950, 700);
        primaryStage.setTitle("Bioland");
        primaryStage.setScene(scene);
        primaryStage.show();
        
        
        
    }
  

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
